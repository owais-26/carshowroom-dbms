"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/edit-message";
exports.ids = ["pages/api/edit-message"];
exports.modules = {

/***/ "mysql2":
/*!*************************!*\
  !*** external "mysql2" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "(api)/./pages/api/edit-message.js":
/*!***********************************!*\
  !*** ./pages/api/edit-message.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _utils_connectDB__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/connectDB */ \"(api)/./utils/connectDB.js\");\n//  /api/edit-message\n//UTILS\n\nconst handler = async (req, res)=>{\n    // Destructure the 'id' and 'text' properties from the request body\n    const { id , text  } = req.body;\n    // Check if the HTTP method is POST\n    if (req.method === \"POST\") {\n        try {\n            // Construct the UPDATE query to update the 'text' field for the given ID\n            const query = `UPDATE messages SET text = '${text}' WHERE id = ${id};`;\n            // Execute the query using the database connection\n            _utils_connectDB__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(query, (error, result)=>{\n                if (error) {\n                    throw error; // Throw an error if the query execution fails\n                } else {\n                    res.send({\n                        status: \"success\",\n                        result\n                    }); // Send a success response with the result\n                }\n            });\n        } catch (error) {\n            console.log(error); // Log any caught errors\n        }\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZWRpdC1tZXNzYWdlLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscUJBQXFCO0FBRXJCLE9BQU87QUFDZ0M7QUFFdkMsTUFBTUMsVUFBVSxPQUFPQyxLQUFLQyxNQUFRO0lBQ2xDLG1FQUFtRTtJQUNuRSxNQUFNLEVBQUVDLEdBQUUsRUFBRUMsS0FBSSxFQUFFLEdBQUdILElBQUlJLElBQUk7SUFFN0IsbUNBQW1DO0lBQ25DLElBQUlKLElBQUlLLE1BQU0sS0FBSyxRQUFRO1FBQ3pCLElBQUk7WUFDRix5RUFBeUU7WUFDekUsTUFBTUMsUUFBUSxDQUFDLDRCQUE0QixFQUFFSCxLQUFLLGFBQWEsRUFBRUQsR0FBRyxDQUFDLENBQUM7WUFFdEUsa0RBQWtEO1lBQ2xESiw4REFBUSxDQUFDUSxPQUFPLENBQUNDLE9BQU9DLFNBQVc7Z0JBQ2pDLElBQUlELE9BQU87b0JBQ1QsTUFBTUEsTUFBTSxDQUFDLDhDQUE4QztnQkFDN0QsT0FBTztvQkFDTE4sSUFBSVEsSUFBSSxDQUFDO3dCQUFFQyxRQUFRO3dCQUFXRjtvQkFBTyxJQUFJLDBDQUEwQztnQkFDckYsQ0FBQztZQUNIO1FBQ0YsRUFBRSxPQUFPRCxPQUFPO1lBQ2RJLFFBQVFDLEdBQUcsQ0FBQ0wsUUFBUSx3QkFBd0I7UUFDOUM7SUFDRixDQUFDO0FBQ0g7QUFFQSxpRUFBZVIsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NydWRhcHAvLi9wYWdlcy9hcGkvZWRpdC1tZXNzYWdlLmpzPzlhOGUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gIC9hcGkvZWRpdC1tZXNzYWdlXHJcblxyXG4vL1VUSUxTXHJcbmltcG9ydCBkYiBmcm9tICcuLi8uLi91dGlscy9jb25uZWN0REInO1xyXG5cclxuY29uc3QgaGFuZGxlciA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gIC8vIERlc3RydWN0dXJlIHRoZSAnaWQnIGFuZCAndGV4dCcgcHJvcGVydGllcyBmcm9tIHRoZSByZXF1ZXN0IGJvZHlcclxuICBjb25zdCB7IGlkLCB0ZXh0IH0gPSByZXEuYm9keTtcclxuXHJcbiAgLy8gQ2hlY2sgaWYgdGhlIEhUVFAgbWV0aG9kIGlzIFBPU1RcclxuICBpZiAocmVxLm1ldGhvZCA9PT0gXCJQT1NUXCIpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIENvbnN0cnVjdCB0aGUgVVBEQVRFIHF1ZXJ5IHRvIHVwZGF0ZSB0aGUgJ3RleHQnIGZpZWxkIGZvciB0aGUgZ2l2ZW4gSURcclxuICAgICAgY29uc3QgcXVlcnkgPSBgVVBEQVRFIG1lc3NhZ2VzIFNFVCB0ZXh0ID0gJyR7dGV4dH0nIFdIRVJFIGlkID0gJHtpZH07YDtcclxuXHJcbiAgICAgIC8vIEV4ZWN1dGUgdGhlIHF1ZXJ5IHVzaW5nIHRoZSBkYXRhYmFzZSBjb25uZWN0aW9uXHJcbiAgICAgIGRiLnF1ZXJ5KHF1ZXJ5LCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xyXG4gICAgICAgIGlmIChlcnJvcikge1xyXG4gICAgICAgICAgdGhyb3cgZXJyb3I7IC8vIFRocm93IGFuIGVycm9yIGlmIHRoZSBxdWVyeSBleGVjdXRpb24gZmFpbHNcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcmVzLnNlbmQoeyBzdGF0dXM6IFwic3VjY2Vzc1wiLCByZXN1bHQgfSk7IC8vIFNlbmQgYSBzdWNjZXNzIHJlc3BvbnNlIHdpdGggdGhlIHJlc3VsdFxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7IC8vIExvZyBhbnkgY2F1Z2h0IGVycm9yc1xyXG4gICAgfVxyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXI7Il0sIm5hbWVzIjpbImRiIiwiaGFuZGxlciIsInJlcSIsInJlcyIsImlkIiwidGV4dCIsImJvZHkiLCJtZXRob2QiLCJxdWVyeSIsImVycm9yIiwicmVzdWx0Iiwic2VuZCIsInN0YXR1cyIsImNvbnNvbGUiLCJsb2ciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/edit-message.js\n");

/***/ }),

/***/ "(api)/./utils/connectDB.js":
/*!****************************!*\
  !*** ./utils/connectDB.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mysql2 */ \"mysql2\");\n/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mysql2__WEBPACK_IMPORTED_MODULE_1__);\n// Import required dependencies\n\n\n// Create a MySQL database connection\nconst db = mysql2__WEBPACK_IMPORTED_MODULE_1___default().createConnection({\n    host: \"localhost\",\n    user: \"root\",\n    password: \"owaismysql123\",\n    database: \"messages_schema\"\n});\n// Export the database connection as the default export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9jb25uZWN0REIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSwrQkFBK0I7QUFDTDtBQUNDO0FBRTNCLHFDQUFxQztBQUNyQyxNQUFNRSxLQUFLRCw4REFBc0IsQ0FBQztJQUNoQ0csTUFBTTtJQUNOQyxNQUFNO0lBQ05DLFVBQVU7SUFDVkMsVUFBVTtBQUNaO0FBRUEsdURBQXVEO0FBQ3ZELGlFQUFlTCxFQUFFQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY3J1ZGFwcC8uL3V0aWxzL2Nvbm5lY3REQi5qcz9jNjE3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydCByZXF1aXJlZCBkZXBlbmRlbmNpZXNcclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgbXlzcWwgZnJvbSBcIm15c3FsMlwiO1xyXG5cclxuLy8gQ3JlYXRlIGEgTXlTUUwgZGF0YWJhc2UgY29ubmVjdGlvblxyXG5jb25zdCBkYiA9IG15c3FsLmNyZWF0ZUNvbm5lY3Rpb24oe1xyXG4gIGhvc3Q6IFwibG9jYWxob3N0XCIsIC8vIE15U1FMIHNlcnZlciBob3N0bmFtZVxyXG4gIHVzZXI6IFwicm9vdFwiLCAvLyBVc2VybmFtZSBmb3IgZGF0YWJhc2UgYWNjZXNzXHJcbiAgcGFzc3dvcmQ6IFwib3dhaXNteXNxbDEyM1wiLCAvLyBQYXNzd29yZCBmb3IgZGF0YWJhc2UgYWNjZXNzXHJcbiAgZGF0YWJhc2U6IFwibWVzc2FnZXNfc2NoZW1hXCIsIC8vIE5hbWUgb2YgdGhlIGRhdGFiYXNlIHRvIGNvbm5lY3QgdG9cclxufSk7XHJcblxyXG4vLyBFeHBvcnQgdGhlIGRhdGFiYXNlIGNvbm5lY3Rpb24gYXMgdGhlIGRlZmF1bHQgZXhwb3J0XHJcbmV4cG9ydCBkZWZhdWx0IGRiO1xyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJteXNxbCIsImRiIiwiY3JlYXRlQ29ubmVjdGlvbiIsImhvc3QiLCJ1c2VyIiwicGFzc3dvcmQiLCJkYXRhYmFzZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./utils/connectDB.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/edit-message.js"));
module.exports = __webpack_exports__;

})();