"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/delete-message";
exports.ids = ["pages/api/delete-message"];
exports.modules = {

/***/ "mysql2":
/*!*************************!*\
  !*** external "mysql2" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "(api)/./pages/api/delete-message.js":
/*!*************************************!*\
  !*** ./pages/api/delete-message.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _utils_connectDB__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/connectDB */ \"(api)/./utils/connectDB.js\");\n//  /api/delete-message\n//UTILS\n\nconst handler = async (req, res)=>{\n    // Check if the HTTP method is POST\n    if (req.method === \"POST\") {\n        try {\n            console.log(req.body); // Log the request body\n            // Construct the DELETE query with the given ID\n            const query = `DELETE FROM messages WHERE id = ${req.body};`;\n            // Execute the query using the database connection\n            _utils_connectDB__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(query, (error, result)=>{\n                if (error) {\n                    throw error; // Throw an error if the query execution fails\n                } else {\n                    res.send({\n                        status: \"success\",\n                        result\n                    }); // Send a success response with the result\n                }\n            });\n        } catch (error) {\n            console.log(error); // Log any caught errors\n        }\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZGVsZXRlLW1lc3NhZ2UuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSx1QkFBdUI7QUFFdkIsT0FBTztBQUNnQztBQUV2QyxNQUFNQyxVQUFVLE9BQU9DLEtBQUtDLE1BQVE7SUFDbEMsbUNBQW1DO0lBQ25DLElBQUlELElBQUlFLE1BQU0sS0FBSyxRQUFRO1FBQ3pCLElBQUk7WUFDRkMsUUFBUUMsR0FBRyxDQUFDSixJQUFJSyxJQUFJLEdBQUcsdUJBQXVCO1lBRTlDLCtDQUErQztZQUMvQyxNQUFNQyxRQUFRLENBQUMsZ0NBQWdDLEVBQUVOLElBQUlLLElBQUksQ0FBQyxDQUFDLENBQUM7WUFFNUQsa0RBQWtEO1lBQ2xEUCw4REFBUSxDQUFDUSxPQUFPLENBQUNDLE9BQU9DLFNBQVc7Z0JBQ2pDLElBQUlELE9BQU87b0JBQ1QsTUFBTUEsTUFBTSxDQUFDLDhDQUE4QztnQkFDN0QsT0FBTztvQkFDTE4sSUFBSVEsSUFBSSxDQUFDO3dCQUFFQyxRQUFRO3dCQUFXRjtvQkFBTyxJQUFJLDBDQUEwQztnQkFDckYsQ0FBQztZQUNIO1FBQ0YsRUFBRSxPQUFPRCxPQUFPO1lBQ2RKLFFBQVFDLEdBQUcsQ0FBQ0csUUFBUSx3QkFBd0I7UUFDOUM7SUFDRixDQUFDO0FBQ0g7QUFFQSxpRUFBZVIsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NydWRhcHAvLi9wYWdlcy9hcGkvZGVsZXRlLW1lc3NhZ2UuanM/NWY4MiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyAgL2FwaS9kZWxldGUtbWVzc2FnZVxyXG5cclxuLy9VVElMU1xyXG5pbXBvcnQgZGIgZnJvbSAnLi4vLi4vdXRpbHMvY29ubmVjdERCJztcclxuXHJcbmNvbnN0IGhhbmRsZXIgPSBhc3luYyAocmVxLCByZXMpID0+IHtcclxuICAvLyBDaGVjayBpZiB0aGUgSFRUUCBtZXRob2QgaXMgUE9TVFxyXG4gIGlmIChyZXEubWV0aG9kID09PSBcIlBPU1RcIikge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc29sZS5sb2cocmVxLmJvZHkpOyAvLyBMb2cgdGhlIHJlcXVlc3QgYm9keVxyXG5cclxuICAgICAgLy8gQ29uc3RydWN0IHRoZSBERUxFVEUgcXVlcnkgd2l0aCB0aGUgZ2l2ZW4gSURcclxuICAgICAgY29uc3QgcXVlcnkgPSBgREVMRVRFIEZST00gbWVzc2FnZXMgV0hFUkUgaWQgPSAke3JlcS5ib2R5fTtgO1xyXG5cclxuICAgICAgLy8gRXhlY3V0ZSB0aGUgcXVlcnkgdXNpbmcgdGhlIGRhdGFiYXNlIGNvbm5lY3Rpb25cclxuICAgICAgZGIucXVlcnkocXVlcnksIChlcnJvciwgcmVzdWx0KSA9PiB7XHJcbiAgICAgICAgaWYgKGVycm9yKSB7XHJcbiAgICAgICAgICB0aHJvdyBlcnJvcjsgLy8gVGhyb3cgYW4gZXJyb3IgaWYgdGhlIHF1ZXJ5IGV4ZWN1dGlvbiBmYWlsc1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXMuc2VuZCh7IHN0YXR1czogXCJzdWNjZXNzXCIsIHJlc3VsdCB9KTsgLy8gU2VuZCBhIHN1Y2Nlc3MgcmVzcG9uc2Ugd2l0aCB0aGUgcmVzdWx0XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKTsgLy8gTG9nIGFueSBjYXVnaHQgZXJyb3JzXHJcbiAgICB9XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgaGFuZGxlcjtcclxuIl0sIm5hbWVzIjpbImRiIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsImNvbnNvbGUiLCJsb2ciLCJib2R5IiwicXVlcnkiLCJlcnJvciIsInJlc3VsdCIsInNlbmQiLCJzdGF0dXMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/delete-message.js\n");

/***/ }),

/***/ "(api)/./utils/connectDB.js":
/*!****************************!*\
  !*** ./utils/connectDB.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mysql2 */ \"mysql2\");\n/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mysql2__WEBPACK_IMPORTED_MODULE_1__);\n// Import required dependencies\n\n\n// Create a MySQL database connection\nconst db = mysql2__WEBPACK_IMPORTED_MODULE_1___default().createConnection({\n    host: \"localhost\",\n    user: \"root\",\n    password: \"owaismysql123\",\n    database: \"messages_schema\"\n});\n// Export the database connection as the default export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9jb25uZWN0REIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSwrQkFBK0I7QUFDTDtBQUNDO0FBRTNCLHFDQUFxQztBQUNyQyxNQUFNRSxLQUFLRCw4REFBc0IsQ0FBQztJQUNoQ0csTUFBTTtJQUNOQyxNQUFNO0lBQ05DLFVBQVU7SUFDVkMsVUFBVTtBQUNaO0FBRUEsdURBQXVEO0FBQ3ZELGlFQUFlTCxFQUFFQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY3J1ZGFwcC8uL3V0aWxzL2Nvbm5lY3REQi5qcz9jNjE3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydCByZXF1aXJlZCBkZXBlbmRlbmNpZXNcclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgbXlzcWwgZnJvbSBcIm15c3FsMlwiO1xyXG5cclxuLy8gQ3JlYXRlIGEgTXlTUUwgZGF0YWJhc2UgY29ubmVjdGlvblxyXG5jb25zdCBkYiA9IG15c3FsLmNyZWF0ZUNvbm5lY3Rpb24oe1xyXG4gIGhvc3Q6IFwibG9jYWxob3N0XCIsIC8vIE15U1FMIHNlcnZlciBob3N0bmFtZVxyXG4gIHVzZXI6IFwicm9vdFwiLCAvLyBVc2VybmFtZSBmb3IgZGF0YWJhc2UgYWNjZXNzXHJcbiAgcGFzc3dvcmQ6IFwib3dhaXNteXNxbDEyM1wiLCAvLyBQYXNzd29yZCBmb3IgZGF0YWJhc2UgYWNjZXNzXHJcbiAgZGF0YWJhc2U6IFwibWVzc2FnZXNfc2NoZW1hXCIsIC8vIE5hbWUgb2YgdGhlIGRhdGFiYXNlIHRvIGNvbm5lY3QgdG9cclxufSk7XHJcblxyXG4vLyBFeHBvcnQgdGhlIGRhdGFiYXNlIGNvbm5lY3Rpb24gYXMgdGhlIGRlZmF1bHQgZXhwb3J0XHJcbmV4cG9ydCBkZWZhdWx0IGRiO1xyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJteXNxbCIsImRiIiwiY3JlYXRlQ29ubmVjdGlvbiIsImhvc3QiLCJ1c2VyIiwicGFzc3dvcmQiLCJkYXRhYmFzZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./utils/connectDB.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/delete-message.js"));
module.exports = __webpack_exports__;

})();